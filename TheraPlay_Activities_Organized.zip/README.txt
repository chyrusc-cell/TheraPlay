THERAPLAY ACTIVITY PACKAGE
==========================

Prepared from the uploaded SAD ZIP.
Selected files are grouped into the six official TheraPlay categories.
Category folder names are standardized to match the project categories exactly.

SELECTION RULES
- Maximum of 15 activity files per category.
- Categories with fewer than 15 suitable files retain all available files.
- Exact duplicate image files are not repeated.
- Color and black-and-white copies of the same worksheet are not counted as separate activities; one color version was selected where applicable.
- Files are renamed using readable activity titles with underscores.
- Original PDF contents are preserved. JFIF images are converted to JPG for broader compatibility.

SELECTED COUNTS
- Executive Function: 15
- Fine Motor Skills: 15
- Functioning Skills: 8
- Handwriting: 10
- Sensory: 15
- Visual: 10
- Total selected files: 73

IMPORTANT IMPORT NOTES
- Treat each file as a candidate activity resource, not as proof that every field needed by the database is present.
- Read the actual PDF/image before writing descriptions, instructions, or difficulty. Do not invent missing details.
- The existing TheraPlay category is named 'Visual'; the source ZIP called this folder 'VISION'.
- Known project note: 'Shadow Matching Pets' is already associated with an existing activity record (activity id 9) and its category is manually managed. Before importing this file, check for an existing matching record. Do not duplicate, overwrite, or automatically reassign its category. Ask the project owner if any action is needed.
- Do not modify existing activity records during bulk import. Run a dry-run/inventory first and report duplicates for approval.
- Do not seed or modify the Conditions table.
- Do not change the six activity categories or rename 'Visual' to 'Vision'.

FILES NOT INCLUDED
- Repetitive shadow-matching variants were reduced to a smaller representative selection.
- Duplicate color/black-and-white worksheet variants were reduced to one selected version.
- Exact duplicate sensory images (including duplicate 'Copy the Pattern' and 'Color Hunt' files) were not repeated.
- Other lower-priority or repetitive candidates were omitted to keep the selected categories within the requested limit.

See the accompanying CSV manifest for original paths and standardized filenames.
